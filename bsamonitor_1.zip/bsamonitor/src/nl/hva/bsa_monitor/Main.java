package nl.hva.bsa_monitor;

import java.util.Scanner;

/**
 * @author pepijn dik
 * @description Bereken bsa punten
 */
public class Main {
    public static void main(String[] args) {
        Vak fys = new Vak("Fasten your Seatbelts", 12);
        Scanner input = new Scanner(System.in);

        //Vraag naar cijfer
        System.out.print("voer behaalde cijfer voor " + fys.getNaam() + " in:");

        fys.setCijfer(input.nextDouble());
        input.nextLine(); //clear enter

        //Print output
        System.out.printf("Vak/Project: %s Cijfer:  %.1f Punten: %d", fys
                .getNaam(), fys.getCijfer(), fys.gehaaldePunten());
    }
}
