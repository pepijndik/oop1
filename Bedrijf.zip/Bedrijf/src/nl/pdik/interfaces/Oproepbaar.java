package nl.pdik.interfaces;

public interface Oproepbaar {
    public void huurIn(int uren);
}
